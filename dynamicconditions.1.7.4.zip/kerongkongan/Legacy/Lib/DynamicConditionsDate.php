<?php

namespace Lib;

use DynamicConditions\Lib\Date;

// If this file is called directly, abort.
if ( ! defined( 'ABSPATH' ) ) {
    die;
}

/**
 * @deprecated Will be removed in future updates. Use DynamicTag\Lib\Date instead.
 * @package Lib
 */
class DynamicConditionsDate extends Date {

}